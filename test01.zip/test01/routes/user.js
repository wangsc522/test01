
/*
 * GET users listing.
 */

exports.list = function(req, res){
  res.send("respond with a resource");
};

exports.createAccount = function(req, res){
	  res.send("建立帳號");
	};