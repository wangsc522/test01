
/*
 * GET home page.
 */

exports.queryAccount = function(req, res){
  res.render('queryAccout', { title: 'Express !!!!',titlename:"wsc" });
};